public class AssemblyException extends Exception
{
	public AssemblyException(String message) {
		super( message );
	}
}
