public interface ISimAssembly
{
	public abstract void setValue(int newValue);
	public abstract int  getValue();	
}
